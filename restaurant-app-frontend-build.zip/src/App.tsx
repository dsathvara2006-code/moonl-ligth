import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import {
  CalendarCheck,
  ChefHat,
  Facebook,
  Instagram,
  MapPin,
  PhoneCall,
  Search,
  ShoppingBag,
  Star,
  Twitter,
  UtensilsCrossed,
  X,
} from "lucide-react";

const categories = ["Chinese", "South Indian", "Punjabi", "Mexican", "Sizzlers"] as const;

type MenuItem = {
  id: string;
  name: string;
  description: string;
  price: number;
  category: (typeof categories)[number];
};

const menuItems: MenuItem[] = [
  {
    id: "chowmein",
    name: "Moonlight Hakka Noodles",
    description: "Wok-tossed noodles with seasonal veggies and a hint of garlic.",
    price: 260,
    category: "Chinese",
  },
  {
    id: "manchurian",
    name: "Crispy Veg Manchurian",
    description: "Golden fried bites glazed in our signature Manchurian sauce.",
    price: 280,
    category: "Chinese",
  },
  {
    id: "sizzling-wok",
    name: "Wok Tossed Schezwan Rice",
    description: "Spicy schezwan rice layered with peppers and spring onions.",
    price: 290,
    category: "Chinese",
  },
  {
    id: "masala-dosa",
    name: "Butter Masala Dosa",
    description: "Crisp dosa filled with spiced potato masala and ghee.",
    price: 220,
    category: "South Indian",
  },
  {
    id: "idli-platter",
    name: "Steamed Idli Platter",
    description: "Soft idlis served with coconut chutney and sambar.",
    price: 180,
    category: "South Indian",
  },
  {
    id: "mangalore-buns",
    name: "Mangalore Buns",
    description: "Sweet banana buns paired with spicy coconut curry.",
    price: 200,
    category: "South Indian",
  },
  {
    id: "paneer-tikka",
    name: "Punjabi Paneer Tikka",
    description: "Char-grilled paneer with bell peppers and mint chutney.",
    price: 340,
    category: "Punjabi",
  },
  {
    id: "dal-makhani",
    name: "Signature Dal Makhani",
    description: "Slow-cooked black lentils finished with cream and butter.",
    price: 320,
    category: "Punjabi",
  },
  {
    id: "butter-naan",
    name: "Butter Garlic Naan",
    description: "Soft tandoori naan brushed with garlic butter.",
    price: 80,
    category: "Punjabi",
  },
  {
    id: "tacos",
    name: "Smoky Veg Tacos",
    description: "Mini tacos filled with smoky beans and fresh salsa.",
    price: 260,
    category: "Mexican",
  },
  {
    id: "enchiladas",
    name: "Creamy Veg Enchiladas",
    description: "Cheesy enchiladas baked with roasted tomato sauce.",
    price: 320,
    category: "Mexican",
  },
  {
    id: "quesadilla",
    name: "Cheese Burst Quesadilla",
    description: "Melted cheese with herbs, folded in toasted tortillas.",
    price: 300,
    category: "Mexican",
  },
  {
    id: "sizzler-italian",
    name: "Italian Garden Sizzler",
    description: "Herb rice, grilled vegetables, and creamy pepper sauce.",
    price: 380,
    category: "Sizzlers",
  },
  {
    id: "sizzler-asian",
    name: "Asian Pepper Sizzler",
    description: "Sizzling platter with asian glaze and stir-fried greens.",
    price: 420,
    category: "Sizzlers",
  },
  {
    id: "sizzler-mex",
    name: "Mexican Fiesta Sizzler",
    description: "Loaded sizzling plate with mexican spices and beans.",
    price: 410,
    category: "Sizzlers",
  },
];

type Thali = {
  id: string;
  name: string;
  description: string;
  price: number;
  highlight?: boolean;
};

const thalis: Thali[] = [
  {
    id: "silver-thali",
    name: "Silver Gujarati Thali",
    description: "Rotli, dal, kadhi, seasonal sabzi, farsan, dessert.",
    price: 420,
  },
  {
    id: "gold-thali",
    name: "Gold Punjabi Thali",
    description: "Butter naan, dal makhani, paneer, jeera rice, salad.",
    price: 520,
  },
  {
    id: "diamond-thali",
    name: "Diamond Thali",
    description: "Premium chef specials with sweets, mocktail & live grill.",
    price: 720,
    highlight: true,
  },
  {
    id: "royal-thali",
    name: "Royal Gujarati Thali",
    description: "Unlimited thali with 3 sabzis, dal, kadhi, sweet.",
    price: 560,
  },
];

const reviewsSeed = [
  {
    name: "Aarav Mehta",
    rating: 5,
    text: "The moonlight ambience is unreal. The Diamond Thali felt like a celebration on a plate.",
  },
  {
    name: "Sanjana Patel",
    rating: 4,
    text: "Loved the sizzlers and the service. The WhatsApp ordering is super convenient!",
  },
  {
    name: "Imran Shaikh",
    rating: 5,
    text: "Perfect family dinner spot. Jain options were clearly marked, which we appreciated.",
  },
];

type CartItem = {
  id: string;
  name: string;
  price: number;
  quantity: number;
};

export function App() {
  const [activeCategory, setActiveCategory] = useState<(typeof categories)[number]>("Chinese");
  const [query, setQuery] = useState("");
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [reviews, setReviews] = useState(reviewsSeed);
  const [reviewForm, setReviewForm] = useState({ name: "", text: "", rating: 5 });
  const [specialThaliOrder, setSpecialThaliOrder] = useState({ thaliId: thalis[0].id, note: "" });

  const filteredItems = useMemo(() => {
    return menuItems.filter((item) => {
      const matchesCategory = item.category === activeCategory;
      const matchesQuery = item.name.toLowerCase().includes(query.toLowerCase());
      return matchesCategory && matchesQuery;
    });
  }, [activeCategory, query]);

  const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
  const totalAmount = cart.reduce((sum, item) => sum + item.quantity * item.price, 0);

  const addItemToCart = (item: { id: string; name: string; price: number }) => {
    setCart((prev) => {
      const existing = prev.find((entry) => entry.id === item.id);
      if (existing) {
        return prev.map((entry) =>
          entry.id === item.id ? { ...entry, quantity: entry.quantity + 1 } : entry
        );
      }
      return [...prev, { id: item.id, name: item.name, price: item.price, quantity: 1 }];
    });
  };

  const addSpecialThali = (event: React.FormEvent) => {
    event.preventDefault();
    const selected = thalis.find((thali) => thali.id === specialThaliOrder.thaliId);
    if (!selected) return;
    const note = specialThaliOrder.note.trim();
    const name = note ? `${selected.name} (Special Note: ${note})` : selected.name;
    addItemToCart({
      id: `special-${selected.id}-${Date.now()}`,
      name,
      price: selected.price,
    });
    setSpecialThaliOrder((prev) => ({ ...prev, note: "" }));
  };

  const removeFromCart = (id: string) => {
    setCart((prev) => prev.filter((entry) => entry.id !== id));
  };

  const whatsappMessage = useMemo(() => {
    if (!cart.length) return "";
    const items = cart.map((entry) => `${entry.name} x${entry.quantity}`).join(", ");
    return `Hello Moonlight, I would like to order: ${items}. Total: ₹${totalAmount}`;
  }, [cart, totalAmount]);

  const submitReview = (event: React.FormEvent) => {
    event.preventDefault();
    if (!reviewForm.name.trim() || !reviewForm.text.trim()) return;
    setReviews((prev) => [
      {
        name: reviewForm.name,
        rating: reviewForm.rating,
        text: reviewForm.text,
      },
      ...prev,
    ]);
    setReviewForm({ name: "", text: "", rating: 5 });
  };

  return (
    <div className="min-h-screen bg-[#0F172A] text-[#F8FAFC]">
      <header className="relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,_rgba(245,158,11,0.25),_transparent_55%)]" />
        <nav className="relative z-10 flex items-center justify-between px-6 py-6 md:px-16">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white/10 backdrop-blur-md">
              <UtensilsCrossed className="h-6 w-6 text-[#F59E0B]" />
            </div>
            <div>
              <p className="text-lg font-semibold">Moonlight Restaurant</p>
              <p className="text-xs text-white/60">Luxury Dining Experience</p>
            </div>
          </div>
          <div className="hidden gap-8 text-sm text-white/70 md:flex">
            <a className="hover:text-white" href="#menu">
              Menu
            </a>
            <a className="hover:text-white" href="#thali">
              Thali Experience
            </a>
            <a className="hover:text-white" href="#reviews">
              Reviews
            </a>
            <a className="hover:text-white" href="#contact">
              Contact
            </a>
          </div>
        </nav>
        <section className="relative z-10 flex min-h-[80vh] flex-col items-start justify-center gap-8 px-6 pb-16 pt-10 md:px-16 md:pt-20">
          <motion.h1
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="max-w-2xl text-4xl font-semibold leading-tight md:text-6xl"
          >
            Taste the Moonlight.
          </motion.h1>
          <p className="max-w-xl text-lg text-white/70">
            Premium Multi-Cuisine Dining in Bhuj. A modern sanctuary with chef-led thalis, sizzlers,
            and moonlit indulgence.
          </p>
          <div className="flex flex-wrap gap-4">
            <button className="min-h-[48px] rounded-full bg-[#F59E0B] px-8 py-3 font-semibold text-[#0F172A] shadow-lg shadow-amber-500/30">
              View Menu
            </button>
            <button className="min-h-[48px] rounded-full border border-white/40 px-8 py-3 font-semibold text-white/80 backdrop-blur-md">
              Book Table
            </button>
          </div>
          <div className="grid gap-4 md:grid-cols-3">
            {[
              { icon: ChefHat, label: "Chef-crafted specials", value: "120+" },
              { icon: CalendarCheck, label: "Private dining slots", value: "12" },
              { icon: Star, label: "Google rating", value: "4.8" },
            ].map((stat) => (
              <div
                key={stat.label}
                className="flex items-center gap-4 rounded-3xl border border-white/10 bg-white/5 p-5 backdrop-blur-md"
              >
                <stat.icon className="h-6 w-6 text-[#F59E0B]" />
                <div>
                  <p className="text-xl font-semibold">{stat.value}</p>
                  <p className="text-xs text-white/60">{stat.label}</p>
                </div>
              </div>
            ))}
          </div>
        </section>
      </header>

      <section id="menu" className="bg-[#0B1224] px-6 py-16 md:px-16">
        <div className="mx-auto max-w-6xl space-y-10">
          <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
            <div>
              <p className="text-sm uppercase tracking-[0.3em] text-white/50">Moonlight Menu</p>
              <h2 className="text-3xl font-semibold">Discover curated flavors</h2>
              <p className="text-white/60">Filter and search in real time for your perfect dish.</p>
            </div>
            <label className="flex items-center gap-3 rounded-full border border-white/10 bg-white/5 px-4 py-2 backdrop-blur-md">
              <Search className="h-5 w-5 text-white/60" />
              <input
                className="w-full bg-transparent text-sm text-white placeholder:text-white/50 focus:outline-none"
                placeholder="Search dishes..."
                value={query}
                onChange={(event) => setQuery(event.target.value)}
              />
            </label>
          </div>
          <div className="sticky top-0 z-10 -mx-6 bg-[#0B1224]/80 px-6 py-4 backdrop-blur">
            <div className="flex flex-wrap gap-3">
              {categories.map((category) => (
                <button
                  key={category}
                  onClick={() => setActiveCategory(category)}
                  className={`min-h-[48px] rounded-full px-6 text-sm font-semibold transition ${
                    activeCategory === category
                      ? "bg-[#F59E0B] text-[#0F172A]"
                      : "border border-white/10 bg-white/5 text-white/70"
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>
          <div className="grid gap-6 md:grid-cols-2">
            {filteredItems.map((item) => (
              <div
                key={item.id}
                className="flex flex-col gap-4 rounded-3xl border border-white/10 bg-gradient-to-br from-white/10 via-white/5 to-transparent p-6 backdrop-blur-md md:flex-row md:items-center md:justify-between"
              >
                <div className="space-y-2">
                  <h3 className="text-lg font-semibold">{item.name}</h3>
                  <p className="text-sm text-white/60">{item.description}</p>
                  <p className="text-[#F59E0B]">₹ {item.price}</p>
                </div>
                <button
                  onClick={() => addItemToCart(item)}
                  className="flex h-12 w-12 items-center justify-center rounded-full border border-[#F59E0B] text-[#F59E0B] transition hover:bg-[#F59E0B] hover:text-[#0F172A]"
                >
                  +
                </button>
              </div>
            ))}
            {!filteredItems.length && (
              <div className="rounded-3xl border border-white/10 bg-white/5 p-6 text-center text-white/60">
                No items found. Try a different search.
              </div>
            )}
          </div>
        </div>
      </section>

      <section id="thali" className="px-6 py-16 md:px-16">
        <div className="mx-auto max-w-6xl space-y-8">
          <div>
            <p className="text-sm uppercase tracking-[0.3em] text-white/50">The Thali Experience</p>
            <h2 className="text-3xl font-semibold">Punjabi & Gujarati Thalis</h2>
            <p className="text-white/60">Swipe to explore our handcrafted thalis under the moonlight.</p>
          </div>
          <div className="flex gap-6 overflow-x-auto pb-4">
            {thalis.map((thali) => (
              <div
                key={thali.id}
                className={`min-w-[280px] rounded-3xl border bg-white/5 p-6 backdrop-blur-md ${
                  thali.highlight
                    ? "border-[#F59E0B] shadow-lg shadow-amber-500/30"
                    : "border-white/10"
                }`}
              >
                <h3 className="text-xl font-semibold">{thali.name}</h3>
                <p className="mt-2 text-sm text-white/70">{thali.description}</p>
                <p className="mt-4 text-[#F59E0B]">₹ {thali.price}</p>
                <button
                  onClick={() => addItemToCart(thali)}
                  className="mt-4 min-h-[48px] w-full rounded-full border border-[#F59E0B] px-4 py-2 text-sm font-semibold text-[#F59E0B] hover:bg-[#F59E0B] hover:text-[#0F172A]"
                >
                  Add Thali
                </button>
              </div>
            ))}
          </div>
          <form
            onSubmit={addSpecialThali}
            className="grid gap-4 rounded-3xl border border-white/10 bg-white/5 p-6 backdrop-blur-md md:grid-cols-[1fr_1fr_auto]"
          >
            <div className="space-y-2">
              <p className="text-sm uppercase tracking-[0.3em] text-white/50">Special Thali Order</p>
              <p className="text-sm text-white/60">
                Customize a thali with your preferences and add it to the WhatsApp cart.
              </p>
            </div>
            <div className="space-y-3">
              <select
                className="w-full rounded-2xl border border-white/10 bg-white/10 px-4 py-3 text-sm text-white focus:outline-none"
                value={specialThaliOrder.thaliId}
                onChange={(event) =>
                  setSpecialThaliOrder((prev) => ({ ...prev, thaliId: event.target.value }))
                }
              >
                {thalis.map((thali) => (
                  <option key={thali.id} value={thali.id} className="text-slate-900">
                    {thali.name}
                  </option>
                ))}
              </select>
              <input
                className="w-full rounded-2xl border border-white/10 bg-white/10 px-4 py-3 text-sm text-white placeholder:text-white/50 focus:outline-none"
                placeholder="Add a special note (extra ghee, no onion, etc.)"
                value={specialThaliOrder.note}
                onChange={(event) =>
                  setSpecialThaliOrder((prev) => ({ ...prev, note: event.target.value }))
                }
              />
            </div>
            <button
              type="submit"
              className="min-h-[48px] rounded-full bg-[#F59E0B] px-6 py-3 font-semibold text-[#0F172A]"
            >
              Add Special Thali
            </button>
          </form>
        </div>
      </section>

      <section id="reviews" className="bg-[#0B1224] px-6 py-16 md:px-16">
        <div className="mx-auto grid max-w-6xl gap-10 lg:grid-cols-[1.2fr_0.8fr]">
          <div className="space-y-6">
            <div>
              <p className="text-sm uppercase tracking-[0.3em] text-white/50">Guest Stories</p>
              <h2 className="text-3xl font-semibold">Real reviews from diners</h2>
            </div>
            <div className="space-y-4">
              {reviews.map((review, index) => (
                <div
                  key={`${review.name}-${index}`}
                  className="rounded-3xl border border-white/10 bg-white/5 p-6 backdrop-blur-md"
                >
                  <div className="flex items-center justify-between">
                    <p className="font-semibold">{review.name}</p>
                    <div className="flex gap-1 text-[#F59E0B]">
                      {Array.from({ length: review.rating }).map((_, starIndex) => (
                        <Star key={starIndex} className="h-4 w-4" />
                      ))}
                    </div>
                  </div>
                  <p className="mt-3 text-sm text-white/70">{review.text}</p>
                </div>
              ))}
            </div>
          </div>
          <form
            onSubmit={submitReview}
            className="space-y-4 rounded-3xl border border-white/10 bg-white/5 p-6 backdrop-blur-md"
          >
            <div>
              <h3 className="text-xl font-semibold">Share your experience</h3>
              <p className="text-sm text-white/60">We love hearing from our guests.</p>
            </div>
            <input
              className="w-full rounded-2xl border border-white/10 bg-white/10 px-4 py-3 text-sm text-white placeholder:text-white/50 focus:outline-none"
              placeholder="Your name"
              value={reviewForm.name}
              onChange={(event) => setReviewForm((prev) => ({ ...prev, name: event.target.value }))}
            />
            <textarea
              className="min-h-[120px] w-full rounded-2xl border border-white/10 bg-white/10 px-4 py-3 text-sm text-white placeholder:text-white/50 focus:outline-none"
              placeholder="Your review"
              value={reviewForm.text}
              onChange={(event) => setReviewForm((prev) => ({ ...prev, text: event.target.value }))}
            />
            <div className="flex items-center justify-between rounded-2xl border border-white/10 bg-white/10 px-4 py-3 text-sm text-white/70">
              <span>Rating</span>
              <select
                className="bg-transparent text-white focus:outline-none"
                value={reviewForm.rating}
                onChange={(event) =>
                  setReviewForm((prev) => ({ ...prev, rating: Number(event.target.value) }))
                }
              >
                {[5, 4, 3, 2, 1].map((rating) => (
                  <option key={rating} value={rating} className="text-slate-900">
                    {rating}
                  </option>
                ))}
              </select>
            </div>
            <button
              type="submit"
              className="min-h-[48px] w-full rounded-full bg-[#F59E0B] px-6 py-3 font-semibold text-[#0F172A]"
            >
              Submit Review
            </button>
          </form>
        </div>
      </section>

      <footer id="contact" className="px-6 pb-28 pt-16 md:px-16">
        <div className="mx-auto grid max-w-6xl gap-10 lg:grid-cols-3">
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white/10 backdrop-blur-md">
                <UtensilsCrossed className="h-6 w-6 text-[#F59E0B]" />
              </div>
              <div>
                <p className="text-lg font-semibold">Moonlight Restaurant</p>
                <p className="text-xs text-white/60">Jain options available on request.</p>
              </div>
            </div>
            <p className="text-sm text-white/60">
              Address: Golden Avenue, Sky Plaza, Bhuj, Gujarat 370001
            </p>
            <div className="flex items-center gap-3 text-sm text-white/70">
              <PhoneCall className="h-4 w-4 text-[#F59E0B]" />
              <a href="tel:+919876543210" className="hover:text-white">
                +91 98765 43210
              </a>
            </div>
            <div className="flex items-center gap-3 text-sm text-white/70">
              <MapPin className="h-4 w-4 text-[#F59E0B]" />
              <span>Coordinates: 23.239783, 69.719080</span>
            </div>
            <div className="flex gap-4 text-sm text-white/60">
              <a
                className="flex items-center gap-2 hover:text-white"
                href="https://instagram.com"
                target="_blank"
                rel="noreferrer"
              >
                <Instagram className="h-4 w-4 text-[#F59E0B]" />
                Instagram
              </a>
              <a
                className="flex items-center gap-2 hover:text-white"
                href="https://facebook.com"
                target="_blank"
                rel="noreferrer"
              >
                <Facebook className="h-4 w-4 text-[#F59E0B]" />
                Facebook
              </a>
              <a
                className="flex items-center gap-2 hover:text-white"
                href="https://twitter.com"
                target="_blank"
                rel="noreferrer"
              >
                <Twitter className="h-4 w-4 text-[#F59E0B]" />
                Twitter
              </a>
            </div>
          </div>
          <div className="rounded-3xl border border-white/10 bg-white/5 p-6 backdrop-blur-md lg:col-span-2">
            <p className="text-sm uppercase tracking-[0.3em] text-white/50">Google Map</p>
            <div className="mt-4 overflow-hidden rounded-2xl border border-white/10">
              <iframe
                title="Moonlight Restaurant Location"
                src="https://maps.google.com/maps?q=23.239783,69.719080&z=15&output=embed"
                className="h-60 w-full"
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </footer>

      {totalItems > 0 && (
        <button
          onClick={() => setIsCartOpen(true)}
          className="fixed bottom-6 right-6 z-50 flex min-h-[56px] items-center gap-3 rounded-full bg-[#F59E0B] px-6 py-3 font-semibold text-[#0F172A] shadow-xl"
        >
          <ShoppingBag className="h-5 w-5" />
          <span>
            Total Items: {totalItems} | ₹ {totalAmount}
          </span>
        </button>
      )}

      {isCartOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 px-6">
          <div className="w-full max-w-lg rounded-3xl border border-white/10 bg-[#0F172A] p-6 shadow-2xl">
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-semibold">Moonlight Cart</h3>
              <button
                onClick={() => setIsCartOpen(false)}
                className="rounded-full border border-white/10 p-2 text-white/70"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="mt-4 space-y-3">
              {cart.map((item) => (
                <div
                  key={item.id}
                  className="flex items-center justify-between rounded-2xl border border-white/10 bg-white/5 px-4 py-3"
                >
                  <div>
                    <p className="font-semibold">{item.name}</p>
                    <p className="text-sm text-white/60">
                      ₹ {item.price} × {item.quantity}
                    </p>
                  </div>
                  <button
                    onClick={() => removeFromCart(item.id)}
                    className="text-sm text-[#F59E0B]"
                  >
                    Remove
                  </button>
                </div>
              ))}
              {!cart.length && <p className="text-white/60">Your cart is empty.</p>}
            </div>
            <div className="mt-6 flex items-center justify-between text-lg font-semibold">
              <span>Total</span>
              <span>₹ {totalAmount}</span>
            </div>
            <a
              href={`https://wa.me/919876543210?text=${encodeURIComponent(whatsappMessage)}`}
              target="_blank"
              rel="noreferrer"
              className="mt-6 block min-h-[48px] rounded-full bg-[#F59E0B] px-6 py-3 text-center font-semibold text-[#0F172A]"
            >
              Order via WhatsApp
            </a>
          </div>
        </div>
      )}
    </div>
  );
}
